const server = require('./base.js');

server.init("0.0.0.0", 80, false);