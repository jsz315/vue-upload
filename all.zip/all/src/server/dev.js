const server = require('./base.js');

server.init("127.0.0.1", 8899, true);