const databaseConfig = {
    // host: "39.98.243.202",
    host: "localhost",
    user: "root",
    password: "Jsz04005301!",
    // password: "Jsz04005301",
    database: "qiniu"
}

const bucket = "three-js-model";
const accessKey = 'MDNdTeEsk_7k4LrKpMwSO_ZtrbOoWPwbMRk4pA8w';
const secretKey = 'vNlCEQ2elBBnxT-h-16kVS-yDzil7qjybSw9K9QK';
const HOST = "http://py325bkfy.bkt.clouddn.com";

module.exports = {
    databaseConfig, 
    bucket,
    accessKey,
    secretKey,
    HOST
}