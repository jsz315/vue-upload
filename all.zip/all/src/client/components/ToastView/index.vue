<template>
    <div class="wrap" v-if="show">{{text}}</div>
  </template>
  

<style lang="less" scoped>
@import url("./index.less");
</style>